export default Text = {
    product: ['Product', 'Mahsulot'],
    developers: ['Developers', 'Dasturchilar'],
    beta: ['Beta', 'Beta'],
    pricing: ['Pricing', 'Narxlash'],
    start: ['Start your project', 'Loyihangizni boshlang'],
    sign: ['Sign in', 'Tizimga kirish'],
    your: ['Your Name', 'Sizning ismingiz'],
    pass: ['Your Password', 'Sizning parolingiz'],
    loginn: ['Login', 'Kirish'],
    database: ['Database', 'Ma`lumotlar bazasi'],
    authen: ['Authentication', 'Autentifikatsiya'],
    storage: ['Storage', 'Saqlash'],
    functionn: ['Functions', 'Funksiyalar'],
    coming: ['Coming soon', 'Tez kunlarda'],
    support: ['Support', 'Qo`llab-quvvatlash'],
    resourse: ['Resources', 'Resurslar']
}