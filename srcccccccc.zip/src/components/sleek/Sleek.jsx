import React from 'react'
// ReactHook
import { useContext } from 'react'
// Css
import './sleek.css'
// Img
import img from '../../images/sleek-img/img.png'
// Context
import { Context } from '../../context/Context'
// react-router-dom
import { Link } from 'react-router-dom'
// Icon
import {RiArrowUpSFill} from 'react-icons/ri'

const Sleek = () => {
    const {logo, dark} = useContext(Context)
  return (
    <div className='sleek'>
        <div className="container">
            <div className="sleek_main">
                <p className={dark ? 'sleek_main_p text_black': 'sleek_main_p'}>Sleek dashboard for managing your media</p>
                <p className={dark ? 'sleek_main_p1 text_black': 'sleek_main_p1'}>A complete Object Explorer so that any of your team can use.</p>
                <p className={dark ? 'sleek_main_p2 text_black': 'sleek_main_p2'}>Drag and drop uploading, moving objects, and multiple object selection. As easy as working on your desktop.</p>
                <div className="sleek_main_div">
                    <div className="sleek_main_div_img">
                        <div className="sleek_main_div_img_btns">
                            <button className='sleek_main_div_img_btn sleek_main_div_img_btn_active'>File previews</button>
                            <button className='sleek_main_div_img_btn'>Column view</button>
                            <button className='sleek_main_div_img_btn'>List view</button>
                            <button className='sleek_main_div_img_btn'>Multi select actions</button>
                            <button className='sleek_main_div_img_btn'>Path navigator</button>
                        </div>
                        <img src={img} alt="" />
                    </div>
                    <div className="sleek_main_div_text">
                        <p className='sleek_main_div_text_p'>File previews</p>
                        <p className='sleek_main_div_text_p1'>Preview any media type, including video and audio.</p>
                        <p className='sleek_main_div_text_p2'>Check out our example app</p>
                        <div className="sleek_main_div_text_div">
                            <p className='sleek_main_div_text_div_p'>Profile management example</p>
                            <p className='sleek_main_div_text_div_p1'>Update a user account with public profile information, including uploading a profile image.</p>
                            <div className='sleek_main_div_text_div_text'>
                                <p className='sleek_main_div_text_div_text_p'>Created by:</p>
                                <img src={logo} alt="" className='img'/>
                            </div>
                        </div>
                        <p className='sleek_main_div_text_div_p2'>nextjs-ts-user-management</p>
                        <Link to='/' className='sleek_main_div_text_div_btn'><span className='sleek_main_div_text_div_btn_icon'><RiArrowUpSFill/></span><span className='sleek_main_div_text_div_btn_span'>Deploy</span></Link>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Sleek