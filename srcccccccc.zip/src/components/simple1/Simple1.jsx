import React from 'react'
// ReactHook
import { useContext } from 'react'
// Css
import './simple1.css'

// Img
import img from '../../images/simple-img/img.png'
import img1 from '../../images/simple-img/img1.png'
import img2 from '../../images/simple-img/img2.png'
// Context
import { Context } from '../../context/Context'


// react-router-dom
import { Link } from 'react-router-dom'

const Simple1 = () => {
    const {dark} = useContext(Context)
    return (
        <div className='simple'>
            <div className="container">
                <div className="simple_main">
                    <div className="simple_main_text">
                        <p className={dark ? 'simple_main_text_p text_black': 'simple_main_text_p'}>Simple and convenient APIs</p>
                        <p className={dark ? 'simple_main_text_p1 text_black': 'simple_main_text_p1'}>Built from the ground-up for interoperable authentication.</p>
                        <p className={dark ? 'simple_main_text_p2 text_black': 'simple_main_text_p2'}>Fast and easy to implement using our powerful library clients. Asset optimization and image transformation coming soon!</p>
                        <div className="simple_main_text_div">
                            <div className="simple_main_text_div1">
                                <div className="simple_main_text_div1_img">
                                    <img src={img} alt="" />
                                </div>
                                <p className='simple_main_text_div1_p'>CDN integration</p>
                                <p className='simple_main_text_div1_p1'>Serve from the edge to reduce latency.</p>
                                <Link to='/' className='simple_main_text_div1_btn'>Coming soon</Link>
                            </div>
                            <div className="simple_main_text_div1">
                                <div className="simple_main_text_div1_img">
                                    <img src={img1} alt="" />
                                </div>
                                <p className='simple_main_text_div1_p'>Auto transformation & optimisation</p>
                                <p className='simple_main_text_div1_p1'>Resize and compress your media before you serve it.</p>
                                <Link to='/' className='simple_main_text_div1_btn'>Coming soon</Link>
                            </div>
                        </div>
                    </div>
                    <div className="simple_main_img">
                        <div className="sleek_main_div_img_btns">
                            <button className='sleek_main_div_img_btn sleek_main_div_img_btn_active'>Upload a file</button>
                            <button className='sleek_main_div_img_btn'>Download a file</button>
                            <button className='sleek_main_div_img_btn'>List files</button>
                            <button className='sleek_main_div_img_btn'>Move and rename files</button>
                            <button className='sleek_main_div_img_btn'>Delete files</button>
                        </div>
                        <img src={img2} alt="" />
                    </div>
                </div>
            </div>
        </div>
      )
}

export default Simple1