import React from 'react'
// ReactHook
import { useContext } from 'react'
// Css
import './hero.css'
// Context
import { Context } from '../../context/Context'
// Img
import img1 from '../../images/hero-img/img1.png'
// react-router-dom
import { Link } from 'react-router-dom'

const Hero = () => {
    const {img, dark} = useContext(Context)
  return (
    <div className='hero'>
        <div className="container">
            <div className="hero_main">
                <div className="hero_main_text">
                    <div className="hero_main_text_delet">
                        <img src={img} alt="" />
                        <p className={dark ? 'hero_main_text_delet_p text_black' : 'hero_main_text_delet_p'}>Storage</p>
                    </div>
                    <p className={dark ? 'hero_main_text_p text_black   ' :'hero_main_text_p'}>Store and serve any type of digital content</p>
                    <p className={dark ? 'hero_main_text_p1 text_black' : 'hero_main_text_p1'}>An open source Object store service with unlimited scalability, for any file type.</p>
                    <p className={dark ? 'hero_main_text_p2 text_black' : 'hero_main_text_p2'}>With custom policies and permissions that are familiar and easy to implement.</p>
                    <Link to='/' className='btn'>Start a project</Link>
                </div>
                <div className="hero_main_img">
                    <img src={img1} alt="" />
                </div>
            </div>
        </div>
    </div>
  )
}

export default Hero