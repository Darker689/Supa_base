import React from 'react'
// ReactHook
import { useContext } from 'react'
// Css
import './simple.css'
// Img
import img from '../../images/simple1-img/img.png'
// Icon
import {BsArrowUpRight} from 'react-icons/bs'
// Context
import { Context } from '../../context/Context'


// react-router-dom
import { Link } from 'react-router-dom'

const Simple = () => {
    const {dark} = useContext(Context)
  return (
    <div className='simple simple1'>
        <div className="container">
            <div className="simple_main">
                <div className="simple_main_text">
                    <p className={dark ? 'simple_main_text_p text_black' : 'simple_main_text_p'}>Integrates natively with Supabase Auth</p>
                    <p className={dark ? 'simple_main_text_p1 text_black' : 'simple_main_text_p1'}>Using Postgres Row Level Security to create Object access rules.</p>
                    <p className={dark ? 'simple_main_text_p2 text_black' : 'simple_main_text_p2'}>Storage Authorization is built around Postgres so that you can use any combination of SQL, Postgres functions, and even your own metadata to write policies.</p>
                    <Link to='/' className='simple_main_text_btn'><BsArrowUpRight className='simple_main_text_btn_icon'/> Expore documentation</Link>
                </div>
                <div className="simple_main_img">
                    <div className="sleek_main_div_img_btns">
                        <button className='sleek_main_div_img_btn sleek_main_div_img_btn_active'>Public access to a bucket</button>
                        <button className='sleek_main_div_img_btn'>Public access to a folder</button>
                        <button className='sleek_main_div_img_btn'>Authenticated access to a bucket</button>
                    </div>
                    <img src={img} alt="" />
                </div>
            </div>
        </div>
    </div>
  )
}

export default Simple;